import tkinter as tk
import random
from spacecraft import Spacecraft
from rover import Rover
from alien import Alien

class MarsGUI:
    def __init__(self, master):
        self.master = master
        self.master.title("Mars Exploration")
        self.canvas = tk.Canvas(self.master, width=600, height=600, bg='black')
        self.canvas.pack()
        self.grid_size = 20
        self.grid_width = 600 // self.grid_size
        self.grid_height = 600 // self.grid_size
        self.grid = [[None for _ in range(self.grid_width)] for _ in range(self.grid_height)]
        self.spacecraft = None
        self.rovers = []
        self.rocks = []
        self.aliens = []
        self.running = False
        self.rovers_with_rocks = set()  # Set to keep track of rovers with rocks
        self.create_mars()
        self.place_spacecraft()
        self.place_rovers()
        self.place_rocks()
        self.place_aliens()
        self.move_rovers()
        self.move_aliens()
        self.create_buttons()
        self.create_legends()  # Add legends

    def create_legends(self):
        legend_font = ('Arial', 10, 'bold')
        self.canvas.create_text(50, 30, text="Spacecraft", fill="white", font=legend_font, anchor="w")
        self.canvas.create_rectangle(20, 25, 40, 35, fill='blue', outline='white')
        self.canvas.create_text(50, 50, text="Rover", fill="white", font=legend_font, anchor="w")
        self.canvas.create_rectangle(20, 45, 40, 55, fill='green', outline='white')
        self.canvas.create_text(50, 70, text="Rock", fill="white", font=legend_font, anchor="w")
        self.canvas.create_rectangle(20, 65, 40, 75, fill='gray', outline='white')
        self.canvas.create_text(50, 90, text="Alien", fill="white", font=legend_font, anchor="w")
        self.canvas.create_oval(20, 85, 40, 105, fill='red', outline='white')

    def create_mars(self):
        for y in range(self.grid_height):
            for x in range(self.grid_width):
                self.grid[y][x] = self.canvas.create_rectangle(
                    x * self.grid_size, y * self.grid_size,
                    (x + 1) * self.grid_size, (y + 1) * self.grid_size,
                    fill='brown', outline='black'
                )

    def place_spacecraft(self):
        x = self.grid_width // 2
        y = self.grid_height // 2
        self.spacecraft = self.canvas.create_rectangle(
            x * self.grid_size, y * self.grid_size,
            (x + 1) * self.grid_size, (y + 1) * self.grid_size,
            fill='blue', outline='white'
        )

    def place_rovers(self):
        for _ in range(9):  # Place 3 rovers initially
            x = random.randint(0, self.grid_width - 1)
            y = random.randint(0, self.grid_height - 1)
            rover = self.canvas.create_rectangle(
                x * self.grid_size, y * self.grid_size,
                (x + 1) * self.grid_size, (y + 1) * self.grid_size,
                fill='green', outline='white'
            )
            self.rovers.append(rover)

    def place_rocks(self):
        for _ in range(10):  # Place 10 rocks randomly
            x = random.randint(0, self.grid_width - 1)
            y = random.randint(0, self.grid_height - 1)
            rock = self.canvas.create_rectangle(
                x * self.grid_size, y * self.grid_size,
                (x + 1) * self.grid_size, (y + 1) * self.grid_size,
                fill='gray', outline='white'
            )
            self.rocks.append(rock)

    def place_aliens(self):
        for _ in range(5):  # Place 5 aliens randomly
            x = random.randint(0, self.grid_width - 1)
            y = random.randint(0, self.grid_height - 1)
            alien = self.canvas.create_oval(
                x * self.grid_size, y * self.grid_size,
                (x + 1) * self.grid_size, (y + 1) * self.grid_size,
                fill='red', outline='white'
            )
            self.aliens.append(alien)

    def move_rovers(self):
        if self.running:
            for rover in self.rovers:
                if rover in self.rovers_with_rocks:  # Check if rover has collected a rock
                    dx, dy = self.get_direction_towards_spacecraft(*self.get_rover_position(rover))
                    new_x, new_y = self.get_new_position(rover, dx, dy)
                    if (new_x, new_y) == self.get_spacecraft_position():  # Check if rover reached spacecraft
                        self.deliver_rocks_to_spacecraft(rover)
                    else:
                        self.canvas.move(rover, dx * self.grid_size, dy * self.grid_size)
                else:  # If rover doesn't have a rock, move randomly
                    dx, dy = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
                    new_x, new_y = self.get_new_position(rover, dx, dy)
                    if (new_x, new_y) in [(rx, ry) for rx, ry in map(self.get_position, self.rocks)]:
                        self.collect_rock(rover, (new_x, new_y))
                    else:
                        if 0 <= new_x < self.grid_width and 0 <= new_y < self.grid_height:
                            self.canvas.move(rover, dx * self.grid_size, dy * self.grid_size)
            if not self.rovers:  # Check if all rovers are damaged
                self.stop_simulation()
            if not self.rocks:  # Check if all rocks are delivered to spacecraft
                self.stop_simulation()
            self.master.after(100, self.move_rovers)

    def move_aliens(self):
        if self.running:
            for alien in self.aliens:
                if random.random() < 0.8:  # 80% chance to move
                    self.move_alien(alien)
                # Check for collisions with rovers
                alien_pos = self.get_position(alien)
                for rover in self.rovers:
                    rover_pos = self.get_position(rover)
                    if alien_pos == rover_pos:
                        self.destroy_rover(rover)  # Destroy rover if collided with an alien
            self.master.after(100, self.move_aliens)

    def move_alien(self, alien):
        dx, dy = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        new_x, new_y =        dx, dy = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        new_x, new_y = self.get_new_position(alien, dx, dy)
        if 0 <= new_x < self.grid_width and 0 <= new_y < self.grid_height:
            self.canvas.move(alien, dx * self.grid_size, dy * self.grid_size)

    def get_new_position(self, item, dx, dy):
        x1, y1, x2, y2 = self.canvas.coords(item)
        new_x1 = x1 + dx * self.grid_size
        new_y1 = y1 + dy * self.grid_size
        new_x2 = x2 + dx * self.grid_size
        new_y2 = y2 + dy * self.grid_size
        return new_x1 // self.grid_size, new_y1 // self.grid_size

    def collect_rock(self, rover, rock_pos):
        if rover not in self.rovers_with_rocks:  # Check if rover already has a rock
            rock = next(rock for rock in self.rocks if self.get_position(rock) == rock_pos)
            self.rocks.remove(rock)
            self.canvas.delete(rock)
            self.canvas.itemconfig(rover, fill='yellow')
            self.rovers_with_rocks.add(rover)  # Add rover to set of rovers with rocks
            if not self.rocks:  # Check if all rocks are delivered to spacecraft
                self.stop_simulation()

    def destroy_rover(self, rover):
        self.canvas.delete(rover)
        self.rovers.remove(rover)
        if not self.rovers:  # Check if all rovers are damaged
            self.stop_simulation()

    def get_rover_position(self, rover):
        x1, y1, x2, y2 = self.canvas.coords(rover)
        x = int((x1 + x2) // 2 // self.grid_size)
        y = int((y1 + y2) // 2 // self.grid_size)
        return x, y

    def start_simulation(self):
        self.running = True
        self.move_rovers()
        self.move_aliens()

    def stop_simulation(self):
        self.running = False

    def create_buttons(self):
        start_button = tk.Button(self.master, text="Start", command=self.start_simulation)
        start_button.pack(side=tk.LEFT)
        stop_button = tk.Button(self.master, text="Stop", command=self.stop_simulation)
        stop_button.pack(side=tk.LEFT)

    def deliver_rocks_to_spacecraft(self, rover):
        self.rovers_with_rocks.remove(rover)  # Remove rover from rovers with rocks
        self.canvas.itemconfig(rover, fill='green')  # Reset rover color
        self.canvas.itemconfig(self.spacecraft, fill='blue')  # Highlight spacecraft
        self.canvas.update()
        self.master.after(1000, lambda: self.canvas.itemconfig(self.spacecraft, fill='black'))

    def get_direction_towards_spacecraft(self, x, y):
        spacecraft_x, spacecraft_y = self.get_spacecraft_position()
        dx = 1 if spacecraft_x > x else -1 if spacecraft_x < x else 0
        dy = 1 if spacecraft_y > y else -1 if spacecraft_y < y else 0
        return dx, dy

    def get_spacecraft_position(self):
        x1, y1, x2, y2 = self.canvas.coords(self.spacecraft)
        x = int((x1 + x2) // 2 // self.grid_size)
        y = int((y1 + y2) // 2 // self.grid_size)
        return x, y

    def get_position(self, item):
        x1, y1, x2, y2 = self.canvas.coords(item)
        x = int((x1 + x2) // 2 // self.grid_size)
        y = int((y1 + y2) // 2 // self.grid_size)
        return x, y



