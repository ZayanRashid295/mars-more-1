import tkinter as tk
from constants import GRID_SIZE, GRID_WIDTH, GRID_HEIGHT

def create_mars_grid(canvas):
    grid = []
    for y in range(GRID_HEIGHT):
        row = []
        for x in range(GRID_WIDTH):
            rect = canvas.create_rectangle(
                x * GRID_SIZE, y * GRID_SIZE,
                (x + 1) * GRID_SIZE, (y + 1) * GRID_SIZE,
                fill='brown', outline='black'
            )
            row.append(rect)
        grid.append(row)
    return grid

def get_new_position(item, dx, dy):
    x1, y1, x2, y2 = item
    new_x1 = x1 + dx * GRID_SIZE
    new_y1 = y1 + dy * GRID_SIZE
    new_x2 = x2 + dx * GRID_SIZE
    new_y2 = y2 + dy * GRID_SIZE
    return new_x1 // GRID_SIZE, new_y1 // GRID_SIZE

def get_position(item):
    x1, y1, x2, y2 = item
    x = int((x1 + x2) // 2 // GRID_SIZE)
    y = int((y1 + y2) // 2 // GRID_SIZE)
    return x, y

# Add more utility functions as needed...
