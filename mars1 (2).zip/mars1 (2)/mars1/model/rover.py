import random

class Rover:
    def __init__(self, canvas, grid_size, grid_width, grid_height):
        self.canvas = canvas
        self.grid_size = grid_size
        self.grid_width = grid_width
        self.grid_height = grid_height
        self.rover = None
        self.create_rover()

    def create_rover(self):
        x = random.randint(0, self.grid_width - 1)
        y = random.randint(0, self.grid_height - 1)
        self.rover = self.canvas.create_rectangle(
            x * self.grid_size, y * self.grid_size,
            (x + 1) * self.grid_size, (y + 1) * self.grid_size,
            fill='green', outline='white'
        )

    def move(self):
        dx, dy = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        new_x, new_y = self.get_new_position(dx, dy)
        if (new_x, new_y) in [(rx, ry) for rx, ry in map(self.get_position, self.rocks)]:
            self.collect_rock((new_x, new_y))
        else:
            if 0 <= new_x < self.grid_width and 0 <= new_y < self.grid_height:
                self.canvas.move(self.rover, dx * self.grid_size, dy * self.grid_size)

    def get_new_position(self, dx, dy):
        x1, y1, x2, y2 = self.canvas.coords(self.rover)
        new_x1 = x1 + dx * self.grid_size
        new_y1 = y1 + dy * self.grid_size
        new_x2 = x2 + dx * self.grid_size
        new_y2 = y2 + dy * self.grid_size
        return new_x1 // self.grid_size, new_y1 // self.grid_size

    def get_position(self):
        x1, y1, x2, y2 = self.canvas.coords(self.rover)
        x = int((x1 + x2) // 2 // self.grid_size)
        y = int((y1 + y2) // 2 // self.grid_size)
        return x, y
