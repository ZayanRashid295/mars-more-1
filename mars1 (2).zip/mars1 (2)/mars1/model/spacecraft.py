import tkinter as tk

class Spacecraft:
    def __init__(self, canvas, grid_size, grid_width, grid_height):
        self.canvas = canvas
        self.grid_size = grid_size
        self.grid_width = grid_width
        self.grid_height = grid_height
        self.spacecraft = None
        self.create_spacecraft()

    def create_spacecraft(self):
        x = self.grid_width // 2
        y = self.grid_height // 2
        self.spacecraft = self.canvas.create_rectangle(
            x * self.grid_size, y * self.grid_size,
            (x + 1) * self.grid_size, (y + 1) * self.grid_size,
            fill='blue', outline='white'
        )

    def get_position(self):
        x1, y1, x2, y2 = self.canvas.coords(self.spacecraft)
        x = int((x1 + x2) // 2 // self.grid_size)
        y = int((y1 + y2) // 2 // self.grid_size)
        return x, y
