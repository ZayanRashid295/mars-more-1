import random

class Rover:
    def __init__(self, canvas, grid_size, rovers_with_rocks, spacecraft_position, rover_id):
        self.canvas = canvas
        self.grid_size = grid_size
        self.rovers_with_rocks = rovers_with_rocks
        self.spacecraft_position = spacecraft_position
        self.rover_id = rover_id
        self.rover = None
        self.battery_level = 100  # Initialize battery level to 100%
        self.place_rover()

    def place_rover(self):
        spacecraft_x, spacecraft_y = self.spacecraft_position
        # Generate initial position close to the spacecraft
        x = random.randint(max(0, spacecraft_x - 5), min(29, spacecraft_x + 5))
        y = random.randint(max(0, spacecraft_y - 5), min(29, spacecraft_y + 5))
        self.rover = self.canvas.create_rectangle(
            x * self.grid_size, y * self.grid_size,
            (x + 1) * self.grid_size, (y + 1) * self.grid_size,
            fill='blue', outline='white'
        )

    def move_rover(self, rock_positions, destroy_rover, collect_rock):
        self.battery_level -= 5  # Reduce battery by 5% per move
        if self.battery_level <= 50:
            print(f"Rover {self.rover_id}'s battery is low. Returning to spacecraft for charging.")
            self.move_to_spacecraft()
        else:
            if self.rover in self.rovers_with_rocks:
                dx, dy = self.get_direction_towards_spacecraft(*self.get_position(), *self.spacecraft_position)
                new_x, new_y = self.get_new_position(dx, dy)
                if (new_x, new_y) == self.spacecraft_position:
                    self.deliver_rocks_to_spacecraft()
                else:
                    self.canvas.move(self.rover, dx * self.grid_size, dy * self.grid_size)
            else:
                dx, dy = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
                new_x, new_y = self.get_new_position(dx, dy)
                if (new_x, new_y) in rock_positions:
                    collect_rock(self, (new_x, new_y))
                else:
                    if 0 <= new_x < 30 and 0 <= new_y < 30:
                        self.canvas.move(self.rover, dx * self.grid_size, dy * self.grid_size)

    def move_to_spacecraft(self):
        dx, dy = self.get_direction_towards_spacecraft(*self.get_position(), *self.spacecraft_position)
        new_x, new_y = self.get_new_position(dx, dy)
        if (new_x, new_y) == self.spacecraft_position:
            self.battery_level = 100  # Fully charge the battery
            print(f"Rover {self.rover_id} is fully charged.")
        else:
            self.canvas.move(self.rover, dx * self.grid_size, dy * self.grid_size)

    def get_direction_towards_spacecraft(self, x, y, spacecraft_x, spacecraft_y):
        dx = 1 if spacecraft_x > x else -1 if spacecraft_x < x else 0
        dy = 1 if spacecraft_y > y else -1 if spacecraft_y < y else 0
        return dx, dy

    def get_new_position(self, dx, dy):
        x1, y1, x2, y2 = self.canvas.coords(self.rover)
        new_x1 = x1 + dx * self.grid_size
        new_y1 = y1 + dy * self.grid_size
        new_x2 = x2 + dx * self.grid_size
        new_y2 = y2 + dy * self.grid_size
        return new_x1 // self.grid_size, new_y1 // self.grid_size

    def deliver_rocks_to_spacecraft(self):
        self.rovers_with_rocks.remove(self.rover)
        self.canvas.itemconfig(self.rover, fill='green')

    def get_position(self):
        x1, y1, x2, y2 = self.canvas.coords(self.rover)
        x = int((x1 + x2) // 2 // self.grid_size)
        y = int((y1 + y2) // 2 // self.grid_size)
        return x, y
