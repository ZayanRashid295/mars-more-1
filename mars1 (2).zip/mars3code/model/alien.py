import random

class Alien:
    def __init__(self, canvas, grid_size):
        self.canvas = canvas
        self.grid_size = grid_size
        self.alien = None
        self.place_alien()

    def place_alien(self):
        x = random.randint(0, 29)
        y = random.randint(0, 29)
        self.alien = self.canvas.create_rectangle(
            x * self.grid_size, y * self.grid_size,
            (x + 1) * self.grid_size, (y + 1) * self.grid_size,
            fill='green', outline='white'
        )

    def move_alien(self):
        dx, dy = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        new_x, new_y = self.get_new_position(dx, dy)
        if 0 <= new_x < 30 and 0 <= new_y < 30:
            self.canvas.move(self.alien, dx * self.grid_size, dy * self.grid_size)

    def get_new_position(self, dx, dy):
        x1, y1, x2, y2 = self.canvas.coords(self.alien)
        new_x1 = x1 + dx * self.grid_size
        new_y1 = y1 + dy * self.grid_size
        new_x2 = x2 + dx * self.grid_size
        new_y2 = y2 + dy * self.grid_size
        return new_x1 // self.grid_size, new_y1 // self.grid_size

    def get_position(self):
        x1, y1, x2, y2 = self.canvas.coords(self.alien)
        x = int((x1 + x2) // 2 // self.grid_size)
        y = int((y1 + y2) // 2 // self.grid_size)
        return x, y
