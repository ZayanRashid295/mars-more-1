import random

class Rock:
    def __init__(self, canvas, grid_size):
        self.canvas = canvas
        self.grid_size = grid_size
        self.rock = None
        self.place_rock()

    def place_rock(self):
        x = random.randint(0, 29)
        y = random.randint(0, 29)
        self.rock = self.canvas.create_rectangle(
            x * self.grid_size, y * self.grid_size,
            (x + 1) * self.grid_size, (y + 1) * self.grid_size,
            fill='black', outline='white'
        )

    def get_position(self):
        x1, y1, x2, y2 = self.canvas.coords(self.rock)
        x = int((x1 + x2) // 2 // self.grid_size)
        y = int((y1 + y2) // 2 // self.grid_size)
        return x, y
