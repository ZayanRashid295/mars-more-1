class Spacecraft:
    def __init__(self, canvas, grid_size):
        self.canvas = canvas
        self.grid_size = grid_size
        self.spacecraft = None
        self.place_spacecraft()

    def place_spacecraft(self):
        x = 15
        y = 15
        self.spacecraft = self.canvas.create_rectangle(
            x * self.grid_size, y * self.grid_size,
            (x + 1) * self.grid_size, (y + 1) * self.grid_size,
            fill='red', outline='white'
        )

    def get_position(self):
        x1, y1, x2, y2 = self.canvas.coords(self.spacecraft)
        x = int((x1 + x2) // 2 // self.grid_size)
        y = int((y1 + y2) // 2 // self.grid_size)
        return x, y
