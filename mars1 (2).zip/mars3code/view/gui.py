import tkinter as tk
import random

from model.rover import Rover
from model.rock import Rock
from model.alien import Alien
from model.spacecraft import Spacecraft


class MarsGUI:
    def __init__(self, master):
        self.master = master
        self.master.title("Mars Exploration")

        self.rovers = []
        self.rocks = []
        self.aliens = []
        self.rovers_with_rocks = set()

        self.create_legends()  # Create and pack legends first

        self.canvas = tk.Canvas(self.master, width=800, height=800, bg='white')
        self.canvas.pack()

        self.grid_size = 25
        self.grid_width = 800 // self.grid_size
        self.grid_height = 800 // self.grid_size
        self.grid = [[None for _ in range(self.grid_width)] for _ in range(self.grid_height)]

        self.spacecraft = None
        self.running = False

        self.create_mars()
        self.place_spacecraft()
        self.place_rovers()
        self.place_rocks()
        self.place_aliens()

        self.create_buttons()

        self.move_rovers()
        self.move_aliens()

    def create_legends(self):
        legend_frame = tk.Frame(self.master)
        legend_frame.pack()

        tk.Label(legend_frame, text="Spacecraft", bg='red', fg='white', width=12).pack(side=tk.LEFT, padx=5)
        self.rover_label = tk.Label(legend_frame, text=f"Rovers: {len(self.rovers)}", bg='blue', fg='white', width=12)
        self.rover_label.pack(side=tk.LEFT, padx=5)
        self.rock_label = tk.Label(legend_frame, text=f"Rocks: {len(self.rocks)}", bg='black', fg='white', width=12)
        self.rock_label.pack(side=tk.LEFT, padx=5)
        self.alien_label = tk.Label(legend_frame, text=f"Aliens: {len(self.aliens)}", bg='green', fg='white', width=12)
        self.alien_label.pack(side=tk.LEFT, padx=5)

    def create_mars(self):
        for y in range(self.grid_height):
            for x in range(self.grid_width):
                self.grid[y][x] = self.canvas.create_rectangle(
                    x * self.grid_size + 1, y * self.grid_size + 1,
                    (x + 1) * self.grid_size - 1, (y + 1) * self.grid_size - 1,
                    fill='white', outline='black'
                )

    def place_spacecraft(self):
        self.spacecraft = Spacecraft(self.canvas, self.grid_size)

    def place_rovers(self):
        spacecraft_position = self.spacecraft.get_position()
        for rover_id in range(9):
            rover = Rover(self.canvas, self.grid_size, self.rovers_with_rocks, spacecraft_position, rover_id)
            self.rovers.append(rover)
        self.update_legends()

    def place_rocks(self):
        for _ in range(100):
            rock = Rock(self.canvas, self.grid_size)
            self.rocks.append(rock)
        self.update_legends()

    def place_aliens(self):
        for _ in range(5):
            alien = Alien(self.canvas, self.grid_size)
            self.aliens.append(alien)
        self.update_legends()

    def move_rovers(self):
        if self.running:
            rock_positions = [rock.get_position() for rock in self.rocks]
            for rover in self.rovers:
                rover.move_rover(rock_positions, self.destroy_rover, self.collect_rock)
            if not self.rovers:
                self.stop_simulation()
            if not self.rocks:
                self.stop_simulation()
            self.master.after(100, self.move_rovers)

    def move_aliens(self):
        if self.running:
            for alien in self.aliens:
                if random.random() < 0.8:
                    alien.move_alien()
            alien_positions = [alien.get_position() for alien in self.aliens]
            for rover in self.rovers:
                rover_pos = rover.get_position()
                if rover_pos in alien_positions:
                    self.destroy_rover(rover)
            self.master.after(100, self.move_aliens)

    def start_simulation(self):
        self.running = True
        self.move_rovers()
        self.move_aliens()

    def stop_simulation(self):
        self.running = False

    def create_buttons(self):
        button_frame = tk.Frame(self.master)
        button_frame.pack(side=tk.TOP)

        start_button = tk.Button(button_frame, text="Start", command=self.start_simulation)
        start_button.pack(side=tk.LEFT)

        stop_button = tk.Button(button_frame, text="Stop", command=self.stop_simulation)
        stop_button.pack(side=tk.LEFT)

    def collect_rock(self, rover, rock_position):
        rock_to_remove = next((rock for rock in self.rocks if rock.get_position() == rock_position), None)
        if rock_to_remove:
            self.rovers_with_rocks.add(rover.rover)
            rover.canvas.itemconfig(rover.rover, fill='yellow')
            self.rocks.remove(rock_to_remove)
            rover.canvas.delete(rock_to_remove.rock)
        self.update_legends()

    def destroy_rover(self, rover):
        self.rovers.remove(rover)
        self.canvas.delete(rover.rover)
        self.update_legends()

    def update_legends(self):
        self.rover_label.config(text=f"Rovers: {len(self.rovers)}")
        self.rock_label.config(text=f"Rocks: {len(self.rocks)}")
        self.alien_label.config(text=f"Aliens: {len(self.aliens)}")


if __name__ == "__main__":
    root = tk.Tk()
    app = MarsGUI(root)
    root.mainloop()
